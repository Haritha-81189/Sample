package com.vishnu.db;



public interface Logindb {
	
	public void Insert(Object[]  vis);

}
