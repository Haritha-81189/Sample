package com.vishnu.db;



public interface Feedbackdb {
	
	public void Insert(Object[]  vis);

}
