package com.vishnu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.vishnu.db.Feedbackdatabase;
import com.vishnu.db.Feedbackdb;
import com.vishnu.dto.FeedbackDTO;

@Controller
public class Feedbackcontroller {
	@GetMapping("/")
	public String showstudentList() {
		
		return "home-page";
		
	}
	
	@RequestMapping("/sucess")
	public String regstudentList(FeedbackDTO feedbackDTO) {
		
		Object[] vis= {feedbackDTO.getName(),
		feedbackDTO.getEmail(),feedbackDTO.getFeedback()};
		
		
		Feedbackdatabase feedbackdatabase =new Feedbackdatabase();
		feedbackdatabase.Insert(vis);
		
		
		
		return "feedback-success";
	}
	@RequestMapping("/link")
	public String showpage() {
		return "feedback";
	}
	

}
